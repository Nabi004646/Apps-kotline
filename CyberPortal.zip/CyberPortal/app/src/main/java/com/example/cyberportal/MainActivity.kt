package com.example.cyberportal

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.navigation.compose.*
import com.example.cyberportal.ui.*

private enum class Tab(val route: String, val label: String, val icon: ImageVector) {
    Home("home", "Home", Icons.Default.Home),
    Passwords("passwords", "Passwords", Icons.Default.Lock),
    Links("links", "Links", Icons.Default.Search),
    Learn("learn", "Quiz", Icons.Default.Check),
    Report("report", "Report", Icons.Default.Warning)
}

class MainActivity : ComponentActivity() {
    private val vm: PortalViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            PortalTheme {
                val nav = rememberNavController()
                val current by nav.currentBackStackEntryAsState()
                Scaffold(
                    containerColor = MaterialTheme.colorScheme.background,
                    bottomBar = {
                        NavigationBar {
                            Tab.entries.forEach { t ->
                                NavigationBarItem(
                                    selected = current?.destination?.route == t.route,
                                    onClick = {
                                        nav.navigate(t.route) {
                                            popUpTo(Tab.Home.route); launchSingleTop = true
                                        }
                                    },
                                    icon = { androidx.compose.material3.Icon(t.icon, t.label) },
                                    label = { Text(t.label) }
                                )
                            }
                        }
                    }
                ) { pad ->
                    NavHost(nav, Tab.Home.route, Modifier.padding(pad)) {
                        composable(Tab.Home.route) { DashboardScreen(vm) }
                        composable(Tab.Passwords.route) { PasswordLabScreen() }
                        composable(Tab.Links.route) { LinkCheckScreen() }
                        composable(Tab.Learn.route) { QuizScreen(vm) }
                        composable(Tab.Report.route) { ReportScreen(vm) }
                    }
                }
            }
        }
    }
}
