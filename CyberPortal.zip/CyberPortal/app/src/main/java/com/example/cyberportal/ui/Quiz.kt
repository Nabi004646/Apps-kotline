package com.example.cyberportal.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.cyberportal.PortalViewModel

private data class Q(val q: String, val options: List<String>, val answer: Int, val why: String)

private val questions = listOf(
    Q("An SMS says your bank account is locked and asks you to tap a link. What do you do?",
        listOf("Tap the link and log in", "Reply STOP", "Open the bank's official app or site yourself", "Forward it to friends"), 2,
        "Urgent lock messages are a classic phishing pattern. Go to the official app directly."),
    Q("Which is the strongest choice for an email account?",
        listOf("A long unique password plus two-factor authentication", "Your birthday", "One good password reused everywhere", "Password123!"), 0,
        "Unique passwords and a second factor protect you even after a breach elsewhere."),
    Q("Someone calls, says they are from tech support, and asks for the OTP you just received.",
        listOf("Read it out, they are official", "Refuse and hang up", "Ask them to call back later", "Send it by SMS instead"), 1,
        "Genuine staff never need your one-time code."),
    Q("Where should you install apps from?",
        listOf("Any APK link shared in a group", "The official app store", "A forum post", "A file from a USB stick"), 1,
        "Official stores scan for malware; random APKs do not get that check."),
    Q("You find a USB drive in a car park. What is safest?",
        listOf("Plug it in to find the owner", "Plug it into a work laptop", "Do not plug it in", "Format it on your phone"), 2,
        "Unknown drives can carry malware. Hand it in without connecting it."),
    Q("Public Wi-Fi is fine for which of these?",
        listOf("Online banking", "Reading a public news page", "Entering card details", "Logging in to work email without MFA"), 1,
        "Treat public Wi-Fi as untrusted for anything sensitive.")
)

@Composable
fun QuizScreen(vm: PortalViewModel) {
    var index by remember { mutableIntStateOf(0) }
    var score by remember { mutableIntStateOf(0) }
    var picked by remember { mutableStateOf<Int?>(null) }
    var finished by remember { mutableStateOf(false) }

    Column(
        Modifier.verticalScroll(rememberScrollState()).padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("Awareness quiz", style = MaterialTheme.typography.headlineMedium)
        Text("Best score: ${vm.bestQuiz} / ${questions.size}", style = MaterialTheme.typography.bodySmall)

        if (finished) {
            Text("You scored $score of ${questions.size}", style = MaterialTheme.typography.titleLarge)
            Button(onClick = { index = 0; score = 0; picked = null; finished = false }) { Text("Try again") }
        } else {
            val q = questions[index]
            Text("Question ${index + 1} of ${questions.size}", style = MaterialTheme.typography.labelLarge)
            Text(q.q, style = MaterialTheme.typography.titleMedium)
            q.options.forEachIndexed { i, opt ->
                val chosen = picked
                val container = when {
                    chosen == null -> MaterialTheme.colorScheme.surface
                    i == q.answer -> Safe.copy(alpha = 0.25f)
                    i == chosen -> Danger.copy(alpha = 0.25f)
                    else -> MaterialTheme.colorScheme.surface
                }
                Card(
                    onClick = { if (picked == null) { picked = i; if (i == q.answer) score++ } },
                    colors = CardDefaults.cardColors(containerColor = container),
                    modifier = Modifier.fillMaxWidth()
                ) { Text(opt, Modifier.padding(14.dp)) }
            }
            if (picked != null) {
                Text(q.why, style = MaterialTheme.typography.bodyMedium)
                Button(onClick = {
                    if (index == questions.lastIndex) { vm.submitQuiz(score); finished = true }
                    else { index++; picked = null }
                }) { Text(if (index == questions.lastIndex) "See result" else "Next question") }
            }
        }
    }
}
