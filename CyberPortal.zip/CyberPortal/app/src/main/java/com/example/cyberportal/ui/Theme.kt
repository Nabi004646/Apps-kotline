package com.example.cyberportal.ui

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val Safe = Color(0xFF2E7D5B)
val Caution = Color(0xFFB7791F)
val Danger = Color(0xFFB3382C)

private val Light = lightColorScheme(
    primary = Color(0xFF1F5F7A), onPrimary = Color.White,
    background = Color(0xFFF3F6F8), onBackground = Color(0xFF14212B),
    surface = Color.White, onSurface = Color(0xFF14212B),
    surfaceVariant = Color(0xFFE3EAEF), error = Danger
)
private val Dark = darkColorScheme(
    primary = Color(0xFF7CC4DE), onPrimary = Color(0xFF0B2530),
    background = Color(0xFF0F1A21), onBackground = Color(0xFFE6EEF2),
    surface = Color(0xFF172630), onSurface = Color(0xFFE6EEF2),
    surfaceVariant = Color(0xFF22343F), error = Color(0xFFE57B70)
)

@Composable
fun PortalTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = if (isSystemInDarkTheme()) Dark else Light, content = content)
}
