package com.example.cyberportal.security

import java.net.URI

enum class Verdict { LIKELY_SAFE, SUSPICIOUS, DANGEROUS }

data class LinkFinding(val text: String, val points: Int)
data class LinkReport(val verdict: Verdict, val findings: List<LinkFinding>)

/** Heuristic, offline link inspection. It cannot prove a site is safe. */
object LinkAnalyzer {
    private val shorteners = setOf("bit.ly", "tinyurl.com", "t.co", "goo.gl", "ow.ly", "is.gd", "cutt.ly")
    private val riskyTlds = setOf("zip", "mov", "xyz", "top", "click", "country", "gq", "tk", "ml")
    private val bait = listOf("login", "verify", "secure", "update", "account", "wallet", "bank", "password", "confirm")
    private val brands = listOf("paypal", "google", "microsoft", "apple", "amazon", "facebook", "netflix", "esewa", "khalti")

    fun analyze(input: String): LinkReport {
        val raw = input.trim()
        val f = mutableListOf<LinkFinding>()
        val uri = try { URI(if ("://" in raw) raw else "http://$raw") } catch (e: Exception) { null }
        val host = uri?.host?.lowercase()
        if (raw.isBlank() || host == null) {
            return LinkReport(Verdict.SUSPICIOUS, listOf(LinkFinding("Could not read a valid address", 2)))
        }
        if (uri.scheme != "https") f += LinkFinding("Not using HTTPS", 2)
        if (Regex("^\\d{1,3}(\\.\\d{1,3}){3}$").matches(host)) f += LinkFinding("Uses a raw IP address instead of a name", 3)
        if ("@" in raw.substringBefore("?")) f += LinkFinding("Contains '@', which can hide the real destination", 3)
        if (host.contains("xn--")) f += LinkFinding("Internationalised (punycode) domain, may imitate another site", 3)
        if (host in shorteners) f += LinkFinding("Shortened link hides the destination", 2)
        if (host.count { it == '.' } >= 4) f += LinkFinding("Unusually many subdomains", 2)
        if (raw.length > 100) f += LinkFinding("Very long address", 1)
        if (host.substringAfterLast('.') in riskyTlds) f += LinkFinding("Domain ending often abused for scams", 1)
        if (host.count { it == '-' } >= 3) f += LinkFinding("Many hyphens in the domain", 1)

        val hits = bait.filter { host.contains(it) }
        if (hits.isNotEmpty()) f += LinkFinding("Urgent-action words in domain: ${hits.joinToString()}", 2)

        val root = host.split('.').takeLast(2).joinToString(".")
        brands.firstOrNull { host.contains(it) && !root.startsWith("$it.") }?.let {
            f += LinkFinding("Mentions \"$it\" but the real domain is $root", 4)
        }
        if (Regex("[a-z][0-9][a-z]").containsMatchIn(root.substringBefore('.'))) {
            f += LinkFinding("Digits mixed into letters (e.g. paypa1)", 2)
        }

        val score = f.sumOf { it.points }
        val verdict = when {
            score >= 6 -> Verdict.DANGEROUS
            score >= 2 -> Verdict.SUSPICIOUS
            else -> Verdict.LIKELY_SAFE
        }
        return LinkReport(verdict, f)
    }
}
