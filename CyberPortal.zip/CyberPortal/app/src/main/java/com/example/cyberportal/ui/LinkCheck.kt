package com.example.cyberportal.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.cyberportal.security.LinkAnalyzer
import com.example.cyberportal.security.LinkReport
import com.example.cyberportal.security.Verdict

@Composable
fun LinkCheckScreen() {
    var url by remember { mutableStateOf("") }
    var report by remember { mutableStateOf<LinkReport?>(null) }

    Column(
        Modifier.verticalScroll(rememberScrollState()).padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("Link check", style = MaterialTheme.typography.headlineMedium)
        Text(
            "Paste a link from a message or email. The check runs offline and looks for common phishing signs. It cannot prove a link is safe.",
            style = MaterialTheme.typography.bodySmall
        )
        OutlinedTextField(
            value = url, onValueChange = { url = it; report = null },
            label = { Text("https://…") }, modifier = Modifier.fillMaxWidth()
        )
        Button(onClick = { report = LinkAnalyzer.analyze(url) }, enabled = url.isNotBlank()) { Text("Check link") }

        report?.let { r ->
            val (label, color) = when (r.verdict) {
                Verdict.LIKELY_SAFE -> "No warning signs found" to Safe
                Verdict.SUSPICIOUS -> "Suspicious" to Caution
                Verdict.DANGEROUS -> "Likely phishing" to Danger
            }
            Text(label, style = MaterialTheme.typography.titleLarge, color = color)
            r.findings.forEach { Text("• ${it.text}", style = MaterialTheme.typography.bodyMedium) }
            if (r.verdict != Verdict.LIKELY_SAFE) {
                Text("Do not enter passwords or codes. Open the official site by typing it yourself.",
                    style = MaterialTheme.typography.bodyMedium)
            }
        }
    }
}
