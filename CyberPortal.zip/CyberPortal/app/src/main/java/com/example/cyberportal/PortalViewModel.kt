package com.example.cyberportal

import android.app.Application
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel

data class CheckItem(val id: String, val title: String, val why: String, val done: Boolean = false)
data class Incident(val type: String, val details: String, val time: Long = System.currentTimeMillis())

class PortalViewModel(app: Application) : AndroidViewModel(app) {
    private val prefs = app.getSharedPreferences("portal", 0)

    val checklist = mutableStateListOf<CheckItem>()
    val incidents = mutableStateListOf<Incident>()
    var bestQuiz by mutableIntStateOf(prefs.getInt("bestQuiz", 0))
        private set

    init {
        val done = prefs.getStringSet("done", emptySet()) ?: emptySet()
        listOf(
            CheckItem("lock", "Screen lock is on", "A PIN or biometric stops casual access if your phone is lost."),
            CheckItem("update", "System and apps are up to date", "Updates patch known vulnerabilities."),
            CheckItem("2fa", "Two-factor authentication on email and banking", "A stolen password alone is not enough to get in."),
            CheckItem("manager", "Using a password manager", "Unique passwords everywhere limit the damage of one breach."),
            CheckItem("store", "Installing apps only from official stores", "Sideloaded apps are the most common malware route."),
            CheckItem("wifi", "Avoiding banking on public Wi-Fi", "Use mobile data or a trusted VPN instead."),
            CheckItem("backup", "Backups are enabled", "Backups are your recovery plan against ransomware or loss."),
            CheckItem("find", "Find-my-device is enabled", "Lets you locate or remotely wipe a lost phone.")
        ).forEach { checklist += it.copy(done = it.id in done) }
    }

    fun toggle(id: String) {
        val i = checklist.indexOfFirst { it.id == id }
        if (i < 0) return
        checklist[i] = checklist[i].copy(done = !checklist[i].done)
        prefs.edit().putStringSet("done", checklist.filter { it.done }.map { it.id }.toSet()).apply()
    }

    fun submitQuiz(score: Int) {
        if (score > bestQuiz) { bestQuiz = score; prefs.edit().putInt("bestQuiz", score).apply() }
    }

    fun report(type: String, details: String) { incidents.add(0, Incident(type, details)) }
}
