package com.example.cyberportal.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.cyberportal.PortalViewModel

@Composable
fun DashboardScreen(vm: PortalViewModel) {
    val done = vm.checklist.count { it.done }
    val total = vm.checklist.size
    val pct = done * 100 / total
    val color = when { pct >= 75 -> Safe; pct >= 40 -> Caution; else -> Danger }

    LazyColumn(
        contentPadding = PaddingValues(20.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            Text("Your phone's security", style = MaterialTheme.typography.headlineMedium)
            Spacer(Modifier.height(12.dp))
            Text("$pct%", style = MaterialTheme.typography.displayMedium, color = color)
            Text("$done of $total protections in place", style = MaterialTheme.typography.bodyMedium)
            Spacer(Modifier.height(8.dp))
            LinearProgressIndicator(
                progress = { done / total.toFloat() },
                modifier = Modifier.fillMaxWidth().height(8.dp),
                color = color
            )
            Spacer(Modifier.height(8.dp))
            Text(
                "Tick each item once you have checked it on your device.",
                style = MaterialTheme.typography.bodySmall
            )
        }
        items(vm.checklist, key = { it.id }) { item ->
            Card(
                Modifier.fillMaxWidth().clickable { vm.toggle(item.id) },
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(checked = item.done, onCheckedChange = { vm.toggle(item.id) })
                    Column(Modifier.padding(start = 8.dp)) {
                        Text(item.title, style = MaterialTheme.typography.titleSmall)
                        Text(item.why, style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
        }
    }
}
