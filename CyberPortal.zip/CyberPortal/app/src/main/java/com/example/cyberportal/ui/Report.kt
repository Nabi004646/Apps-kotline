package com.example.cyberportal.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.cyberportal.PortalViewModel
import java.text.DateFormat
import java.util.Date

private val types = listOf("Phishing", "Scam call", "Lost device", "Suspicious app", "Other")

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun ReportScreen(vm: PortalViewModel) {
    var type by remember { mutableStateOf(types.first()) }
    var details by remember { mutableStateOf("") }

    LazyColumn(contentPadding = PaddingValues(20.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item {
            Text("Report an incident", style = MaterialTheme.typography.headlineMedium)
            Text("Reports are kept in this session only. Connect a backend to send them to your security team.",
                style = MaterialTheme.typography.bodySmall)
            Spacer(Modifier.height(8.dp))
            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                types.forEach { t -> FilterChip(selected = type == t, onClick = { type = t }, label = { Text(t) }) }
            }
            OutlinedTextField(
                value = details, onValueChange = { details = it },
                label = { Text("What happened?") },
                modifier = Modifier.fillMaxWidth().padding(top = 8.dp), minLines = 3
            )
            Button(
                onClick = { vm.report(type, details.trim()); details = "" },
                enabled = details.isNotBlank(), modifier = Modifier.padding(top = 8.dp)
            ) { Text("Submit report") }
            if (vm.incidents.isEmpty()) {
                Text("No reports yet. Anything odd you spot goes here.", Modifier.padding(top = 16.dp))
            }
        }
        items(vm.incidents) { i ->
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(14.dp)) {
                    Text(i.type, style = MaterialTheme.typography.titleSmall)
                    Text(DateFormat.getDateTimeInstance().format(Date(i.time)), style = MaterialTheme.typography.bodySmall)
                    Text(i.details, Modifier.padding(top = 4.dp))
                }
            }
        }
    }
}
