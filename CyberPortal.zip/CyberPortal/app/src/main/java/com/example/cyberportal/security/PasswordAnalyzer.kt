package com.example.cyberportal.security

import java.security.SecureRandom
import kotlin.math.ln

enum class Strength(val label: String) {
    VERY_WEAK("Very weak"), WEAK("Weak"), FAIR("Fair"), STRONG("Strong"), EXCELLENT("Excellent")
}

data class PasswordReport(val strength: Strength, val entropyBits: Int, val issues: List<String>)

object PasswordAnalyzer {
    private val common = listOf(
        "password", "123456", "qwerty", "letmein", "admin", "welcome",
        "iloveyou", "abc123", "monkey", "dragon", "111111", "passw0rd"
    )

    fun analyze(pw: String): PasswordReport {
        if (pw.isEmpty()) return PasswordReport(Strength.VERY_WEAK, 0, emptyList())
        val issues = mutableListOf<String>()
        var pool = 0
        if (pw.any { it.isLowerCase() }) pool += 26
        if (pw.any { it.isUpperCase() }) pool += 26
        if (pw.any { it.isDigit() }) pool += 10
        if (pw.any { !it.isLetterOrDigit() }) pool += 33
        var bits = pw.length * ln(pool.coerceAtLeast(1).toDouble()) / ln(2.0)

        val lower = pw.lowercase()
        if (common.any { lower.contains(it) }) {
            issues += "Contains a very common password or phrase"
            bits = minOf(bits, 20.0)
        }
        if (Regex("(.)\\1{2,}").containsMatchIn(pw)) {
            issues += "Repeats the same character 3+ times"; bits *= 0.8
        }
        if (Regex("(0123|1234|2345|3456|abcd|bcde|qwer|asdf)").containsMatchIn(lower)) {
            issues += "Contains an easy-to-guess sequence"; bits *= 0.8
        }
        if (pw.length < 12) issues += "Use at least 12 characters"
        if (pool < 62) issues += "Mix upper case, lower case, digits and symbols"

        val strength = when {
            bits < 28 -> Strength.VERY_WEAK
            bits < 40 -> Strength.WEAK
            bits < 60 -> Strength.FAIR
            bits < 80 -> Strength.STRONG
            else -> Strength.EXCELLENT
        }
        return PasswordReport(strength, bits.toInt(), issues)
    }

    fun generate(length: Int = 18): String {
        val chars = "ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnpqrstuvwxyz23456789!@#$%^&*-_=+"
        val rnd = SecureRandom()
        return buildString { repeat(length) { append(chars[rnd.nextInt(chars.length)]) } }
    }
}
